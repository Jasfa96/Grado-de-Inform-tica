/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import com.sun.j3d.utils.geometry.Primitive;
import com.sun.j3d.utils.geometry.Sphere;
import java.util.Enumeration;
import java.util.Random;
import javax.media.j3d.Alpha;
import javax.media.j3d.Appearance;
import javax.media.j3d.Behavior;
import javax.media.j3d.BoundingSphere;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.PositionPathInterpolator;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.media.j3d.WakeupOnCollisionEntry;
import javax.vecmath.Point3d;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

/**
 *
 * @author fvelasco
 */
class Pelota extends BranchGroup {
  static private final Random r = new Random();
  private Cancha cancha;
  private Vector3f direccion;
  private Point3f posicion;
  private Point3f nuevaPosicion;
  private Vector3f posicionImpacto;
  private TransformGroup tgPelota;
  private Transform3D trans;
  private Sphere pelota;
  
  private Alpha alfa;
  private PositionPathInterpolator interpolador;
  private ColisionesPelota colisionPelota;
  private int velocidad;
  private float ancho;
  private float alto;
  
  Pelota (Cancha miCancha) {
    Point3f puntos[];
    
    cancha = miCancha;
    ancho = cancha.getAncho();
    alto = cancha.getAlto();
    // El movimiento se realiza entre una posición origen 
    //    y una posición destino
    posicion = new Point3f();
    direccion = new Vector3f();
    nuevaPosicion = new Point3f();
    posicionImpacto = new Vector3f();
    // Se crea la rama (geometría) en el grafo para la pelota
    Appearance app = new RandomColor();
    pelota = new Sphere (0.25f, Primitive.GENERATE_NORMALS, app);
    trans = new Transform3D();
    tgPelota = new TransformGroup (trans);
    tgPelota.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
    tgPelota.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
    tgPelota.addChild(pelota);
    this.addChild(tgPelota);
    
    // El alpha y el interpolador para los movimientos
    velocidad = 100; // Es un tiempo, a valor más bajo, pelota más rápida
    alfa = new Alpha (1,(long)(ancho+alto)*velocidad);
    alfa.pause();
    puntos = new Point3f[2];
    // El movimiento se controla definiendo una posición de origen y una de destino
    // Más el tiempo que se emplea en hacer ese recorrido
    puntos[0] = posicion;
    puntos[1] = nuevaPosicion;
    float knots[] = {0.0f, 1.0f};
    interpolador = new PositionPathInterpolator (alfa, tgPelota, trans, knots, puntos);
    interpolador.setSchedulingBounds(new BoundingSphere (new Point3d (0,0,0), 10));
    tgPelota.addChild(interpolador);
    
    // El comportamiento para las colisiones
    colisionPelota = new ColisionesPelota(this);
    colisionPelota.setEnable(false);
    tgPelota.addChild(colisionPelota);
  }
  
  void empiezaDerecha () {
    float direccionX = r.nextFloat() + 0.5f;
    empieza (direccionX);
  }
  
  void empiezaIzquierda () {
    float direccionX = -r.nextFloat() - 0.5f;
    empieza (direccionX);
  }
  
  private void empieza (float direccionX) {
    direccion = new Vector3f (direccionX, 1, 0);
    direccion.normalize();
    muevePelota();
    colisionPelota.setEnable (true);
  }
  
  private void muevePelota () {
    // La nueva posición se calcula a partir de la posición actual más una distancia fija en la dirección hacia donde se va a mover.
    nuevaPosicion.setX (posicion.x + direccion.x * (ancho+alto));
    nuevaPosicion.setY (posicion.y + direccion.y * (ancho+alto));
    interpolador.setPosition(0, posicion);
    interpolador.setPosition(1, nuevaPosicion);
    alfa.resume();
    alfa.setStartTime(System.currentTimeMillis());    
  }
  
  void colision (Primitive objeto) {
    alfa.pause();
    Colliders tipoObjeto = (Colliders) objeto.getUserData();
    if (tipoObjeto != null) {
      switch (tipoObjeto) {
        case PARED_DERECHA :
        case PARED_IZQUIERDA :
          rebotaLado();
          break;
        case LADRILLO :
          cancha.impactaLadrillo((Ladrillo) objeto.getParent().getParent());
        case PARED_SUPERIOR :
        case RAQUETA :
          rebotaSuperior();
          break;
        case PARED_INFERIOR :
          cancha.pierde ();
          break;
      }
    }
    alfa.resume();
  }
  
  private void rebotaLado () {
    tgPelota.getTransform(trans);
    trans.get(posicionImpacto);
    posicion.set (posicionImpacto);
    // Las esquinas se tratan de manera especial
    if (posicion.y < 1.5 || posicion.y > alto-1) {
      direccion.y *= -1.05f;
      direccion.normalize();
    }
    // Un rebote en los lados cambia la direccíon actual a su simétrica. 
    // En este caso la simetría es multiplicar por -1 la componente X
    direccion.x *= -1;
    muevePelota();
  }
  
  private void rebotaSuperior () {
    tgPelota.getTransform(trans);
    trans.get(posicionImpacto);
    posicion.set (posicionImpacto);
    // En este caso la dirección simétrica, al ser un borde horizontal.
    // Se obtiene multiplicando por -1 la componente Y.
    direccion.y *= -1;
    // Se añade algo de aleatoriedad en los rebotes
    if (r.nextBoolean()) {
      direccion.x += r.nextFloat()*0.25;
    } else {
      direccion.x -= r.nextFloat()*0.25;
    }
    // Se evitan los angulos muy abiertos
    if (direccion.x > 0.7)
      direccion.x -= 0.25;
    else if (direccion.x < -0.7)
      direccion.x += 0.25;
    // Se evitan los angulos cercanos al cero
    if (-0.1 < direccion.x && direccion.x < 0.1)
      direccion.x *= 3;
    // Se tratan las esquinas de manera especial
    if (posicion.x < 1)
      direccion.x = 1.05f;
    else if (posicion.x > ancho-1)
      direccion.x = -1.05f;
    direccion.normalize();
    muevePelota();
  }
  
  Primitive getPrimitive () {
    return pelota;
  }
  
  void pauseResume () {
    if (alfa.isPaused())
      alfa.resume();
    else alfa.pause();
  }
  
  void ponerEnRaqueta (Raqueta raqueta) {
    alfa.pause();
    posicion.set (raqueta.getPosicion());
    posicion.y += 0.5f;
    nuevaPosicion.set (posicion);
    trans.set (new Vector3f (posicion));
    tgPelota.setTransform(trans);
    interpolador.setPosition(0, posicion);
    interpolador.setPosition(1, posicion);
    direccion.y = -1;
    direccion.normalize();
  }
}

class ColisionesPelota extends Behavior {
  private Pelota pelota;
  private WakeupOnCollisionEntry condicion;
  
  ColisionesPelota (Pelota laPelota) {
    pelota = laPelota;
    condicion = new WakeupOnCollisionEntry (pelota.getPrimitive(), WakeupOnCollisionEntry.USE_BOUNDS);
    this.setSchedulingBounds(pelota.getPrimitive().getBounds());
  }
  
  @Override
  public void initialize() {
    wakeupOn(condicion);
  }

  @Override
  public void processStimulus(Enumeration criterios) {
    while (criterios.hasMoreElements()) {
      WakeupOnCollisionEntry disparo = (WakeupOnCollisionEntry) criterios.nextElement();
      Primitive objeto = (Primitive) disparo.getTriggeringPath().getObject().getParent();
      pelota.colision (objeto);
    }
    wakeupOn(condicion);
  }
  
}
