/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import GUI.Visualization;
import com.sun.j3d.utils.image.TextureLoader;
import com.sun.j3d.utils.universe.SimpleUniverse;
import com.sun.j3d.utils.universe.Viewer;
import com.sun.j3d.utils.universe.ViewingPlatform;
import javax.media.j3d.AmbientLight;
import javax.media.j3d.Background;
import javax.media.j3d.BoundingSphere;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.Canvas3D;
import javax.media.j3d.DirectionalLight;
import javax.media.j3d.Light;
import javax.media.j3d.PointLight;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.media.j3d.View;
import javax.vecmath.Color3f;
import javax.vecmath.Point3d;
import javax.vecmath.Vector3d;
import javax.vecmath.Vector3f;

/**
 *
 * @author fvelasco
 */
public class TheUniverse {
  
  private Visualization window;
  private SimpleUniverse universe;
  private Cancha cancha;
  private BranchGroup background;
  private BranchGroup lights;

  
  public TheUniverse (Visualization visualizationWindow) {
    // Atributos de referencia
    window = visualizationWindow;
    // Se crea el universo y la rama de la vista con ese canvas
    universe = createUniverse(window.getCanvas());
    
    // Se crea la rama del fondo y se cuelga al universo
    background = createBackground();
    universe.addBranchGraph(background);
    
    // Se crean y se añaden luces
    lights = createLights();
    universe.addBranchGraph(lights);

    // Se crea la rama de la escena y se cuelga al universo
    cancha = new Cancha();
    universe.addBranchGraph(cancha);
    
  }
  private SimpleUniverse createUniverse (Canvas3D canvas) {
    // Se crea manualmente un ViewingPlatform para poder personalizarlo y asignárselo al universo
    ViewingPlatform viewingPlatform = new ViewingPlatform();
    // Se establece el radio de activación
    viewingPlatform.getViewPlatform().setActivationRadius (100f);
    
    // El punto desde donde se mira, el punto a donde se mira 
    //    y el ángulo de visión se han establecido para que se vean los muros
    //    y los puntos.
    
    // La transformación de vista, dónde se está, a dónde se mira, Vup
    TransformGroup viewTransformGroup = viewingPlatform.getViewPlatformTransform();
    Transform3D viewTransform3D = new Transform3D();
    viewTransform3D.lookAt (new Point3d (7,11,50), new Point3d (7,11,0), new Vector3d (0,1,0));
    viewTransform3D.invert();
    viewTransformGroup.setTransform (viewTransform3D);

    // Se establece el angulo de vision a 20 grados y el plano de recorte trasero
    Viewer viewer = new Viewer (canvas);
    View view = viewer.getView();
    view.setFieldOfView(Math.toRadians(20));
    view.setBackClipDistance(35.0);

    // Se construye y devuelve el Universo con los parametros definidos
    return new SimpleUniverse (viewingPlatform, viewer);
  }
  
  private BranchGroup createBackground () {
    // Se crea el objeto para el fondo y 
    //     se le asigna un área de influencia
    Background backgroundNode = new Background (new TextureLoader ("imgs/back.jpg", null).getImage());
    backgroundNode.setApplicationBounds (new BoundingSphere (new Point3d (7.0, 10.0, 0.0), 100.0));
    
    // Se crea un BranchGroup para devolver el Background
    // Al SimpleUniverse solo se le pueden colgar BranchGroup
    BranchGroup bgBackground = new BranchGroup();
    bgBackground.addChild(backgroundNode);
    return bgBackground;    
  }
  
  private BranchGroup createLights () {
    // Se van a poner 3 luces, una ambiente, una direccional y una puntual
    BranchGroup lightsNode = new BranchGroup();
    BoundingSphere influencingBound = new BoundingSphere (new Point3d (7.0, 10.0, 0.0), 35.0);
    // Se crea la luz ambiente, todas las luces deben tener su área de influencia
    Light aLight = new AmbientLight (new Color3f (0.9f, 0.9f, 0.9f));
    aLight.setInfluencingBounds (influencingBound);
    aLight.setEnable(true);
    lightsNode.addChild(aLight);
    
    // Se crea una luz direccional
    aLight = new DirectionalLight (new Color3f (0.7f, 0.7f, 0.7f), 
                    new Vector3f (1.0f, -1.0f, -4.0f));
    aLight.setInfluencingBounds (influencingBound);
    aLight.setEnable (true);
    lightsNode.addChild(aLight);
    
    // Se crea una luz puntual
    PointLight pLight = new PointLight ();
    pLight.setPosition (7f, 10f, 0f);
    pLight.setInfluencingBounds (influencingBound);
    pLight.setEnable (true);
    lightsNode.addChild(pLight);
    
    return lightsNode;
  }  
  
  public SimpleUniverse getUniverse () {
    return universe;
  }
  
  
}
