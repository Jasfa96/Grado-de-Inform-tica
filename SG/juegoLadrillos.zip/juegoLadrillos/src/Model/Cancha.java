/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import com.sun.j3d.utils.geometry.Box;
import com.sun.j3d.utils.geometry.Primitive;
import java.awt.Font;
import java.util.Random;
import javax.media.j3d.Appearance;
import javax.media.j3d.BoundingSphere;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.Font3D;
import javax.media.j3d.FontExtrusion;
import javax.media.j3d.Material;
import javax.media.j3d.Shape3D;
import javax.media.j3d.Text3D;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.swing.JOptionPane;
import javax.vecmath.Color3f;
import javax.vecmath.Point3d;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

/**
 *
 * @author fvelasco
 */
class Cancha extends BranchGroup {
  
  private BranchGroup murosExteriores;
  private BranchGroup bloqueLadrillos;
  private Raqueta raqueta;
  private Teclado teclado;
  private Pelota pelota;
  private Text3D textoPuntos;
  private int puntos;
  private int nivel;
  private int nivelMaximo;
  private float ancho;
  private float alto;
  
  private boolean juegoEmpezado;
  private int totalLadrillos;
  
  private static final Random r = new Random();
  
  Cancha () {
    this (14, 20);
  }
  
  Cancha (float ancho, float alto) {
    this.ancho = ancho;
    this.alto = alto;
    juegoEmpezado = false;
    nivel = 0;
    // Cada nivel se añade una fila de ladrillos
    // Se ha puesto de límite ocupar 1/3 del tablero
    nivelMaximo = (int) alto / 3;

    // Se implementa el grafo de escena
    // Se construyen ramas y se cuelgan de this
    hacerMurosExteriores();
    this.addChild(murosExteriores);
    bloqueLadrillos = new BranchGroup();
    bloqueLadrillos.setCapability (BranchGroup.ALLOW_CHILDREN_WRITE);
    bloqueLadrillos.setCapability (BranchGroup.ALLOW_CHILDREN_EXTEND);
    this.addChild(bloqueLadrillos);
    raqueta = new Raqueta(2.5f, -1, ancho+1);
    this.addChild(raqueta);
    pelota = new Pelota (this);
    this.addChild(pelota);
    this.addChild(iniciarPuntos());
    teclado = new Teclado (this);
    teclado.setSchedulingBounds(new BoundingSphere (new Point3d (ancho/2, alto/2, 0.0), (ancho+alto)));
    this.addChild(teclado);
    // Se rellenan los ladrillos para el primer nivel
    nuevoNivel();
  }

  private void hacerMurosExteriores () {
    Box superior, inferior, derecha, izquierda;
    murosExteriores = new BranchGroup();
    
    // Se define un material lambertiano para los muros
    Appearance app = new Appearance ();
    app.setMaterial(new Material (
        new Color3f (0.20f, 0.20f, 0.20f),   // Color ambiental
        new Color3f (0.00f, 0.00f, 0.00f),   // Color emisivo
        new Color3f (0.49f, 0.34f, 0.00f),   // Color difuso
        new Color3f (0.89f, 0.79f, 0.00f),   // Color especular
        17.0f ));                            // Brillo
    
    // OJO, las cajas se crean al doble de las dimensiones indicadas
    // Por ejemplo, la siguiente caja es de 16x1x1
    superior = new Box (ancho/2,0.5f,0.5f,Primitive.GENERATE_NORMALS,app);
    
    // Se le asigna la etiqueta para la detección de colisiones
    superior.setUserData(Colliders.PARED_SUPERIOR);
    
    // Se posiciona y se cuelga de su nodo padre
    Transform3D posicion = new Transform3D ();
    posicion.setTranslation (new Vector3f (ancho/2, alto+0.5f, 0));
    TransformGroup tgSuperior = new TransformGroup (posicion);
    tgSuperior.addChild(superior);
    murosExteriores.addChild (tgSuperior);

    inferior = new Box (ancho/2,0.5f,0.5f,Primitive.GENERATE_NORMALS,app);
    inferior.setUserData(Colliders.PARED_INFERIOR);
    posicion = new Transform3D ();
    posicion.set (new Vector3f (ancho/2, -0.5f, 0));
    TransformGroup tgInferior = new TransformGroup (posicion);
    tgInferior.addChild(inferior);
    murosExteriores.addChild (tgInferior);
    
    derecha = new Box (0.5f,alto/2+1,0.5f,Primitive.GENERATE_NORMALS,app);
    derecha.setUserData(Colliders.PARED_DERECHA);
    posicion = new Transform3D ();
    posicion.set (new Vector3f (ancho+0.5f, alto/2, 0));
    TransformGroup tgDerecha = new TransformGroup (posicion);
    tgDerecha.addChild(derecha);
    murosExteriores.addChild (tgDerecha);
    
    izquierda = new Box (0.5f,alto/2+1,0.5f,Primitive.GENERATE_NORMALS,app);
    izquierda.setUserData(Colliders.PARED_IZQUIERDA);
    posicion = new Transform3D ();
    posicion.set (new Vector3f (-0.5f, alto/2, 0));
    TransformGroup tgIzquierda = new TransformGroup (posicion);
    tgIzquierda.addChild(izquierda);
    murosExteriores.addChild (tgIzquierda);
   }
  
  private BranchGroup iniciarPuntos() {
    puntos = 0;
    // El objeto del tipo de letra
    Font3D fuente = new Font3D (new Font ("Helvetica", Font.PLAIN, 2), 
        new FontExtrusion());
    // La geometría del texto
    textoPuntos = new Text3D (fuente, "Puntos: " + puntos, new Point3f (0,alto+2,0));
    // La capacidad para poder actualizarlo
    textoPuntos.setCapability(Text3D.ALLOW_STRING_WRITE);
    
    // La rama de la que cuelga el texto
    BranchGroup bgPuntos = new BranchGroup();
    bgPuntos.addChild (new Shape3D (textoPuntos));
    // Esta geometría no es colisionable
    bgPuntos.setCollidable(false);
    return bgPuntos;
  }
  
  private void nuevoNivel () {
    // Se pone la pelota en la raqueta
    pelota.ponerEnRaqueta (raqueta);
    // Se eliminan los ladrillos antiguos
    if (bloqueLadrillos.numChildren() > 0)
      bloqueLadrillos.removeAllChildren();
    nivel++;
    // Se crean y cuelgan los nuevos ladrillos
    rellenarLadrillos (nivel);
  }
  
  private void nuevaPartida () {
    juegoEmpezado = false;
    nivel = 0;
    puntos = 0;
    textoPuntos.setString ("Puntos: " + puntos);
    raqueta.setRaquetaCentro();
    nuevoNivel();
  }
  
  private void rellenarLadrillos (int filas) {
    totalLadrillos = 0;
    Ladrillo l;
    int ladrillosPorFila = (int) ancho/2 - 1;
    for (int i = 0; i < ladrillosPorFila; i++)
      for (int j = 0; j < filas; j++) {
        // La última fila se rellena completa
        // En las anteriores no se ponen todos los posibles
        // Se ponen unos sí y otros no aleatoriamente
        if (r.nextBoolean() || j == (filas-1)) {
          l = new Ladrillo (this, 
                  i*2f + ancho/2-ladrillosPorFila + 1, -j*2f + alto-2);
          bloqueLadrillos.addChild(l);
          totalLadrillos++;
        }
      }
  }
  
  float getAlto () {
    return alto;
  }
  
  float getAncho () {
    return ancho;
  }
  
  void impactaLadrillo (Ladrillo ladrillo) {
    // Se hace caer el ladrillo y se suman los puntos
    ladrillo.cae();
    totalLadrillos--;
    puntos += nivel*10;
    textoPuntos.setString ("Puntos: " + puntos);
    if (totalLadrillos <= 0) // Se completa un nivel
      if (nivel == nivelMaximo) { // Se completa la partida
        if (JOptionPane.showConfirmDialog(null, 
            "H A S   G A N A D O\n ¿Deseas empezar una nueva partida?", 
            "Rompe Muros", JOptionPane.YES_NO_OPTION) 
            == JOptionPane.YES_OPTION) {
          nuevaPartida();
        } else System.exit(0); // No se desea una nueva partida
      } else { // Se avanza al siguiente nivel
        nuevoNivel ();
        JOptionPane.showMessageDialog(null, "Avanzas de Nivel", 
            "Rompe Muros", JOptionPane.INFORMATION_MESSAGE);
      }
  }
  
  void mueveDerecha () {
    if (!juegoEmpezado) {
      juegoEmpezado = true;
      pelota.empiezaDerecha();
    }
    raqueta.mueveDerecha();
  }
  
  void mueveIzquierda () {
    if (!juegoEmpezado) {
      juegoEmpezado = true;
      pelota.empiezaIzquierda();
    }
    raqueta.mueveIzquierda();
  }
  
  void pauseResume () {
    pelota.pauseResume();
  }
  
  void pierde () {
    if (JOptionPane.showConfirmDialog(null, "              H A S   P E R D I D O \n ¿Deseas empezar una nueva partida?", "Rompe Muros", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
      nuevaPartida();
    } else System.exit(0);
  }
  
}
