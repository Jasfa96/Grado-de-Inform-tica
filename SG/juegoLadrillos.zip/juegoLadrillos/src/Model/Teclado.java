/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.awt.AWTEvent;
import java.awt.event.KeyEvent;
import static java.awt.event.KeyEvent.VK_LEFT;
import static java.awt.event.KeyEvent.VK_RIGHT;
import static java.awt.event.KeyEvent.VK_SPACE;
import java.util.Enumeration;
import javax.media.j3d.Behavior;
import javax.media.j3d.WakeupOnAWTEvent;

/**
 *
 * @author fvelasco
 */
class Teclado extends Behavior {
  private Cancha cancha;
    // Condición de respuesta
  private WakeupOnAWTEvent condicion = 
        new WakeupOnAWTEvent (KeyEvent.KEY_PRESSED);
    
    Teclado (Cancha unaCancha) {
      cancha = unaCancha;
    }
    
    @Override
    public void initialize () {
      wakeupOn (condicion);
    }


  @Override
  public void processStimulus(Enumeration criterios) {
     // Se extrae de los criterios la tecla pulsada
      WakeupOnAWTEvent unCriterio = 
          (WakeupOnAWTEvent) criterios.nextElement();
      AWTEvent[] eventos = unCriterio.getAWTEvent();
      KeyEvent tecla = (KeyEvent) eventos[0];
          // Procesamiento de las pulsaciones
          switch (tecla.getKeyCode ()) {
            // Diversos cases
            case VK_RIGHT :
              cancha.mueveDerecha();
              break;
            case VK_LEFT :
              cancha.mueveIzquierda();
              break;
            case VK_SPACE :
              cancha.pauseResume();
              break;
          } // del switch interno
      // Se establece la siguiente condición de respuesta
      // Es imprescindible hacer esto, para escuchar la siguiente pulsación
      wakeupOn (condicion);    
  }
  
}
