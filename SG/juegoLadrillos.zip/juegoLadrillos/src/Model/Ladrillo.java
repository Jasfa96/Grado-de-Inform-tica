/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import com.sun.j3d.utils.geometry.Box;
import com.sun.j3d.utils.geometry.Primitive;
import java.util.Enumeration;
import javax.media.j3d.Alpha;
import javax.media.j3d.Appearance;
import javax.media.j3d.Behavior;
import javax.media.j3d.BoundingSphere;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.PositionPathInterpolator;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.media.j3d.WakeupOnCollisionEntry;
import javax.vecmath.Point3d;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

/**
 *
 * @author fvelasco
 */
class Ladrillo extends BranchGroup {
  private Cancha cancha;
  private float posX, posY;
  private Box ladrillo;
  private TransformGroup tgLadrillo;
  private PositionPathInterpolator interpolador;
  private ColisionesLadrillo colisionLadrillo;
  private int velocidad;
  
  private Alpha alfa;
  
  Ladrillo (Cancha miCancha, float unaPosX, float unaPosY) {
    Point3f puntos[];
    
    cancha = miCancha;
    posX = unaPosX;
    posY = unaPosY;
    // El color de los ladrillos es aleatorio
    Appearance app = new RandomColor();
    ladrillo = new Box (0.95f, 0.2f, 0.5f, Primitive.GENERATE_NORMALS, app);
    ladrillo.setUserData(Colliders.LADRILLO);
    Transform3D transform = new Transform3D();
    transform.set (new Vector3f (posX, posY, 0f));
    tgLadrillo = new TransformGroup (transform);
    // Al caerse se modifica su transformación, por lo tanto hay que darle la capacidad para ello
    tgLadrillo.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
    tgLadrillo.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
    tgLadrillo.addChild(ladrillo);
    this.addChild(tgLadrillo);
    
    velocidad = 1500;  // Es un tiempo, en milisegundos
    alfa = new Alpha (1,velocidad);
    // Pausando el alfa el ladrillo no cae, ya que el interpolador que controla la animación de la caída
    // se encuentra detenido.
    alfa.pause();
    puntos = new Point3f[2];
    puntos[0] = new Point3f (posX, posY, 0);
    puntos[1] = new Point3f (posX, -1.5f, 0);
    float knots[] = {0.0f, 1.0f};
    // La caida del ladrillo se controla con un interpolador, que va modificando poco a poco la transformación
    // que posiciona el ladrillo. De manera que pase a estar desde la posición puntos[0] a la posicion puntos[1]
    // en el tiempo indicado.
    interpolador = new PositionPathInterpolator (alfa, tgLadrillo, transform, knots, puntos);
    interpolador.setSchedulingBounds(new BoundingSphere (new Point3d (0,0,0), 10));
    interpolador.setEnable(false);
    tgLadrillo.addChild(interpolador);
    
    // Cada ladrillo tambien tiene un detector de colisiones, que se activa si en su caida
    // colisiona con la raqueta. En ese caso se acaba la partida.
    colisionLadrillo = new ColisionesLadrillo(this);
    colisionLadrillo.setEnable(false);
    tgLadrillo.addChild(colisionLadrillo);
    
    this.setCapability(BranchGroup.ALLOW_DETACH);
  }
  
  void cae () {
    ladrillo.setUserData(null);
    // Se inicia el alfa y se habilitan el interpolador y el detector de colisiones.
    alfa.resume();
    alfa.setStartTime(System.currentTimeMillis());    
    interpolador.setEnable(true);
    colisionLadrillo.setEnable(true);
  }
  
  void colision (Primitive objeto) {
    Colliders tipoObjeto = (Colliders) objeto.getUserData();
    if (tipoObjeto != null) {
      switch (tipoObjeto) {
        case RAQUETA :
          cancha.pierde();
          break;
      }
    }
  }
  
  Primitive getPrimitive () {
    return ladrillo;
  }
}

class ColisionesLadrillo extends Behavior {
  private Ladrillo ladrillo;
  private WakeupOnCollisionEntry condicion;
  
  ColisionesLadrillo (Ladrillo elLadrillo) {
    ladrillo = elLadrillo;
    condicion = new WakeupOnCollisionEntry (ladrillo.getPrimitive(), WakeupOnCollisionEntry.USE_GEOMETRY);
    this.setSchedulingBounds(ladrillo.getPrimitive().getBounds());
  }
  
  @Override
  public void initialize() {
    wakeupOn(condicion);
  }

  @Override
  public void processStimulus(Enumeration criterios) {
    WakeupOnCollisionEntry disparo = (WakeupOnCollisionEntry) criterios.nextElement();
    Primitive objeto = (Primitive) disparo.getTriggeringPath().getObject().getParent();
    ladrillo.colision (objeto);
    wakeupOn(condicion);
  }
  
}
