/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.Random;
import javax.media.j3d.Appearance;
import javax.media.j3d.Material;
import javax.vecmath.Color3b;
import javax.vecmath.Color3f;

/**
 *
 * @author fvelasco
 */
public class RandomColor extends Appearance {
  private static final Random r = new Random(System.currentTimeMillis());
  
  RandomColor () {
    float red = r.nextFloat();
    float green = r.nextFloat();
    float blue = r.nextFloat();
    this.setMaterial(new Material (
      new Color3f (red*0.2f, green*0.2f, blue*0.2f),
      new Color3f (0f, 0f, 0f),
      new Color3f (red, green, blue),
      new Color3f (1.0f, 1.0f, 1.0f),
      17
    ));
  }
}
