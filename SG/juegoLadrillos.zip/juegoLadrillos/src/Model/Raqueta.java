/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import com.sun.j3d.utils.geometry.Box;
import com.sun.j3d.utils.geometry.Primitive;
import javax.media.j3d.Appearance;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

/**
 *
 * @author fvelasco
 */
class Raqueta extends BranchGroup {
  private float tamano;
  private float posicion;
  private float limiteIzquierdo;
  private float limiteDerecho;
  private TransformGroup tgPosicion;
  private Transform3D transform;
  private float velocidad;
  
  Raqueta (float unTamano, float unLimiteIzquierdo, float unLimiteDerecho) {
    Box raqueta;
    tamano = unTamano;
    limiteIzquierdo = unLimiteIzquierdo;
    limiteDerecho = unLimiteDerecho;
    // En este caso la velocidad significa cuanto avanza a izquierda o derecha la raqueta con cada pulsación de teclado
    velocidad = 1f;
    
    Appearance app = new RandomColor ();
    raqueta = new Box (tamano/2f, 0.25f, 0.5f, Primitive.GENERATE_NORMALS, app);
    // Se le asigna su etiqueta para saber cuándo se colisiona con la raqueta
    raqueta.setUserData(Colliders.RAQUETA);
    posicion = (limiteDerecho + limiteIzquierdo) / 2;
    transform = new Transform3D();
    tgPosicion = new TransformGroup ();
    // Para poder cambiar la transformación que posiciona la raqueta hay que darle a ese nodo TransformGroup las capacidades adecuadas
    tgPosicion.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
    tgPosicion.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
    tgPosicion.addChild(raqueta);
    setRaquetaCentro();
    this.addChild(tgPosicion);
  }
  
  void mueveDerecha () {
    if ((posicion + velocidad) < (limiteDerecho - tamano/2)) {
      posicion += velocidad;
      // A partir de la nueva posición horizontal se actualiza la transformación que posiciona la raqueta
      transform.set (new Vector3f (posicion, 0.3f, 0));
      tgPosicion.setTransform(transform);
    }
  }

  void mueveIzquierda () {
    if ((posicion - velocidad) > (limiteIzquierdo + tamano/2)) {
      posicion -= velocidad;
      transform.set (new Vector3f (posicion, 0.3f, 0));
      tgPosicion.setTransform(transform);
    }
  }
  
  Point3f getPosicion () {
    return new Point3f (posicion, 0.3f, 0);
  }
  
  void setRaquetaCentro () {
    posicion = (limiteIzquierdo + limiteDerecho) / 2;
    transform.set (new Vector3f (posicion, 0.3f, 0));
    tgPosicion.setTransform(transform);
  }
  
}
