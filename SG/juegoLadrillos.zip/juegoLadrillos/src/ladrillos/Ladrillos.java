/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ladrillos;

import GUI.Visualization;
import Model.TheUniverse;
import com.sun.j3d.utils.universe.SimpleUniverse;
import javax.media.j3d.Canvas3D;

/**
 *
 * @author fvelasco
 */
public class Ladrillos {

  public static void main(String[] args) {
    // Se obtiene la configuración gráfica del sistema y se crea el Canvas3D que va a mostrar la imagen
    Canvas3D canvas = new Canvas3D (SimpleUniverse.getPreferredConfiguration());
    
    // Se construye la ventana que mostrará el juego
    Visualization visualizationWindow = new Visualization (canvas);
        
    // Se crea el universo, incluye una vista para ese canvas
    TheUniverse universe = new TheUniverse (visualizationWindow);
    
    // Se hace la aplicación visible
    visualizationWindow.setVisible(true);
  }
  
}
