/*import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.net.MalformedURLException;
import java.util.*;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;


public class Implementa extends UnicastRemoteObject implements Cliente_I, Servidor_I {
  Map<String , Double> Datos = new HashMap<String, Double>();
  // private InterfazServidor2 server2;
  Double total=0.0;



  public Implementa() throws RemoteException{
    Map<String , Double> Datos = new HashMap<String, Double>();
  }


  public String Registrarse(String nombre) throws RemoteException {

      Datos.put(nombre,0.0);
      return "\nRegistro en el server1 realizada con exito.";
    }

}
*/
