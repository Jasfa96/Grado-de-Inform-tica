echo "Limpiando..."
make clean -s
rm ./logsalida
rm /bin/4raya
echo "Todo limpio!"
