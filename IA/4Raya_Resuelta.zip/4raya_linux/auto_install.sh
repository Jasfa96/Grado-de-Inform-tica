touch logsalida
echo "Compilando..."
make -s > logsalida
echo "Compilación terminada!"
cp ./4raya /bin/4raya
echo "Ahora puede invocar 4raya"
